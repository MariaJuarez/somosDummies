-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_LPS] 
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
select	lps.periodo,
		lps.Año,
		lps.Mes,
		(select apellidos + ', ' + nombres from empleado where idempleado=c.IdEmpleadoPeopleCare) PC,
		(select apellidos + ', ' + nombres from empleado where idempleado=c.Idlds) LDS,
		c.DescCliente,
		cuil.cuil,
		lps.legajo,
		lps.nombre,
		lps.puesto,  
		p.[Nombre del Proyecto],
		p.[Descripción del Proyecto],
		p.herramientas,
		lps.asignacion,
		lps.rmb * lps.asignacion /100 rmb,
		c.grupo,
		p.tipo
from LPS
left join ProyectosLPS p on p.idProyectoLPS = lps.idProyectoLPS
left join Cliente c on c.IdCliente = p.idcliente
inner join cuil on cuil.legajo=lps.legajo
order by lps.nombre,periodo,año,mes
END

go

